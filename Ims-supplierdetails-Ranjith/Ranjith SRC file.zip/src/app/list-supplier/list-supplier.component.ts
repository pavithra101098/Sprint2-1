import { Component, OnInit } from '@angular/core';
import { SupplierService, Supplier } from '../supplier.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-supplier',
  templateUrl: './list-supplier.component.html',
  styleUrls: ['./list-supplier.component.css']
})
export class ListSupplierComponent implements OnInit {

    suppliers: Supplier[];
    constructor(private supplierservice:SupplierService,private router: Router) { }
  
    ngOnInit(): void {
      this.supplierservice.getAllSuppliers().subscribe(
        response =>(this.handleSuccessfulResponse(response)),
        );
    }
    
    handleSuccessfulResponse(response){
          
      this.suppliers= response;
    }
    viewSupplier(supplier: Supplier): void {
      this.supplierservice.viewSupplier(supplier)
        .subscribe( data => {
          this.suppliers = this.suppliers.filter(u => u !== supplier); });
    }
    
    }
    

