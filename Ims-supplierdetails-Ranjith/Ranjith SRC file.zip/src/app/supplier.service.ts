import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
export class Supplier{
  static orderId: string;
constructor(
   public supplierName:string,	public supplierAddress:string,public supplierNumber:number,
) {}
}
@Injectable({
  providedIn: 'root'
})
export class SupplierService {
  viewSupplier(supplier: Supplier) {
    throw new Error("Method not implemented.");
  }
  getAllSuppliers() {
    throw new Error("Method not implemented.");
  }
  getAllShows() {
    throw new Error("Method not implemented.");
  }
  suppliers: Supplier[];
  constructor(private httpService : HttpClient) { }
  addSupplier(suppliers):Observable<Supplier> {
    console.log(suppliers);
    return this.httpService.post<Supplier>("http://localhost:8091/supplier/insert",suppliers);
  }

getAllSupplies(){
  return this.httpService.get<Supplier[]>("http://localhost:8091/Supplier/viewAll");
}
}

