import { Component, OnInit } from '@angular/core';
import { Supplier, SupplierService} from '../supplier.service';
import{Router}from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  user: Supplier = new Supplier(0,"","","",0);

  constructor(
    private showservice:SupplierService,private router:Router){}
  

  ngOnInit(): void {
  }
addSupplier():void{
  console.log(this.user);
  this.supplierservice.addShow(this.user).subscribe(data =>{ alert("Supplier is added successfully.");});
}
}
