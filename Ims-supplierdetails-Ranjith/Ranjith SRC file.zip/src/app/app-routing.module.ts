import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListSupplierComponent } from './list-supplier/list-supplier.component';
import { AppComponent } from './app.component';
import { AddComponent } from './add/add.component';


const routes: Routes = [
  {path:'addsupplier',component:AddComponent},
  {path:'listsupplier',component:ListSupplierComponent},
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
