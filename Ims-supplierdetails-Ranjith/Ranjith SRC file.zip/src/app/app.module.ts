import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
//import { AddComponent } from './add/add.component';
import { HttpClient,HttpClientModule } from '@angular/common/http';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { SupplierService } from './supplier.service';
import { ListSupplierComponent } from './list-supplier/list-supplier.component';
import { AddComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,
    AddComponent,
    ListSupplierComponent,
    FooterComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,SupplierService],
  bootstrap: [AppComponent]
})
export class AppModule { }
